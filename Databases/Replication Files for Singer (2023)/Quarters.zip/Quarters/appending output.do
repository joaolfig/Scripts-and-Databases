*APPENDING R OUTPUT FOR QUARTERS
** BE SURE TO REPLCE [directory] WITH YOUR WORKING DIRECTORY

**appending files. APPROVAL SMOOTHED
clear
use "[directory]\files and code for SEAD dataset v1\Quarters\state names.dta", clear

levelsof state, local(levels)
clear
cd "[directory]\files and code for SEAD dataset v1\Quarters\app_series\"
foreach a of local levels {
import delimited "`a'_data_q_app_smooth.txt", delimiter(space) clear 
gen state="`a'"
rename v1 year
replace v2=v2/10
rename v2 quarter
rename v3 Approval_Smoothed

sa "[directory]\files and code for SEAD dataset v1\Quarters\stata\app_series_smoothed\wcalc_`a'_app_smooth.dta", replace
}

cd "[directory]\files and code for SEAD dataset v1\Quarters\stata\app_series_smoothed\"
local flist : dir . files "*.dta"
dis `"`flist'"'
foreach f in `flist' {
    append using "`f'"

}
 
gen qtr=yq(year, quarter)
format qtr %tq
label variable Approval_Smoothed "Executive Approval: Smoothed"
duplicates drop
sort state year quarter
saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly app smoothed.dta", replace version(12)


**appending files. APPROVAL NOT SMOOTHED
clear
use "[directory]\files and code for SEAD dataset v1\Quarters\state names.dta", clear

levelsof state, local(levels)
clear
cd "[directory]\files and code for SEAD dataset v1\Quarters\app_series_not_smoothed\"
foreach a of local levels {
import delimited "`a'_data_q_app_not_smooth.txt", delimiter(space) clear 
gen state="`a'"
rename v1 year
replace v2=v2/10
rename v2 quarter
rename v3 Approval_Not_Smoothed

sa "[directory]\files and code for SEAD dataset v1\Quarters\stata\app_series_not_smoothed\wcalc_`a'_app_not_smooth.dta", replace
}


cd "[directory]\files and code for SEAD dataset v1\Quarters\stata\app_series_not_smoothed\"
local flist : dir . files "*.dta"
dis `"`flist'"'
foreach f in `flist' {
    append using "`f'"

}

gen qtr=yq(year, quarter)
format qtr %tq
label variable Approval_Not_Smoothed "Executive Approval: Not Smoothed"
duplicates drop
sort state year quarter

saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly app not smoothed.dta", replace version(12)


**appending files. app_appdis SMOOTHED
clear
use "[directory]\files and code for SEAD dataset v1\Quarters\state names.dta", clear

levelsof state, local(levels)
clear
cd "[directory]\files and code for SEAD dataset v1\Quarters\app_appdis\"
foreach a of local levels {
import delimited "`a'_data_q_App_AppDis_smooth.txt", delimiter(space) clear 
gen state="`a'"
rename v1 year
replace v2=v2/10
rename v2 quarter
rename v3 app_appdis_Smoothed

sa "[directory]\files and code for SEAD dataset v1\Quarters\stata\app_appdis_smoothed\wcalc_`a'_app_appdis_smooth.dta", replace
}


cd "[directory]\files and code for SEAD dataset v1\Quarters\stata\app_appdis_smoothed\"
local flist : dir . files "*.dta"
dis `"`flist'"'
foreach f in `flist' {
    append using "`f'"

}
 
gen qtr=yq(year, quarter)
format qtr %tq
label variable app_appdis_Smoothed "Executive Relative Approval: Smoothed"
duplicates drop
sort state year quarter
saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly app_appdis smoothed.dta", replace version(12)


**appending files. app_appdis NOT SMOOTHED
clear
use "[directory]\files and code for SEAD dataset v1\Quarters\state names.dta", clear

levelsof state, local(levels)
clear
cd "[directory]\files and code for SEAD dataset v1\Quarters\app_appdis_not_smoothed\"
foreach a of local levels {
import delimited "`a'_data_q_App_AppDis_not_smooth.txt", delimiter(space) clear 
gen state="`a'"
rename v1 year
replace v2=v2/10
rename v2 quarter
rename v3 app_appdis_Not_Smoothed

sa "[directory]\files and code for SEAD dataset v1\Quarters\app_appdis_not_smoothed\wcalc_`a'_app_appdis_not_smooth.dta", replace
}


cd "[directory]\files and code for SEAD dataset v1\Quarters\app_appdis_not_smoothed\"
local flist : dir . files "*.dta"
dis `"`flist'"'
foreach f in `flist' {
    append using "`f'"

}

gen qtr=yq(year, quarter)
format qtr %tq
label variable app_appdis_Not_Smoothed "Executive Relative Approval: Not Smoothed"
duplicates drop
sort state year quarter
saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly app_appdis not smoothed.dta", replace version(12)

**appending files. Negative SMOOTHED
clear
use "[directory]\files and code for SEAD dataset v1\Quarters\state names.dta", clear

levelsof state, local(levels)
clear
cd "[directory]\files and code for SEAD dataset v1\Quarters\neg_series\"
foreach a of local levels {
import delimited "`a'_data_q_neg_smooth.txt", delimiter(space) clear 
gen state="`a'"
rename v1 year
replace v2=v2/10
rename v2 quarter
rename v3 Disapproval_Smoothed

sa "[directory]\files and code for SEAD dataset v1\Quarters\stata\neg_series_smoothed\wcalc_`a'_neg_smooth.dta", replace
}

cd "[directory]\files and code for SEAD dataset v1\Quarters\stata\neg_series_smoothed\"
local flist : dir . files "*.dta"
dis `"`flist'"'
foreach f in `flist' {
    append using "`f'"

}
 
gen qtr=yq(year, quarter)
format qtr %tq
label variable Disapproval_Smoothed "Executive Disapproval: Smoothed"
duplicates drop
sort state year quarter
saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly neg smoothed.dta", replace version(12)


**appending files. Negative NOT SMOOTHED
clear
use "[directory]\files and code for SEAD dataset v1\Quarters\state names.dta", clear

levelsof state, local(levels)
clear
cd "[directory]\files and code for SEAD dataset v1\Quarters\neg_series_not_smoothed\"
foreach a of local levels {
import delimited "`a'_data_q_neg_not_smooth.txt", delimiter(space) clear 
gen state="`a'"
rename v1 year
replace v2=v2/10
rename v2 quarter
rename v3 Disapproval_Not_Smoothed

sa "[directory]\files and code for SEAD dataset v1\Quarters\stata\neg_series_not_smoothed\wcalc_`a'_app_not_smooth.dta", replace
}


cd "[directory]\files and code for SEAD dataset v1\Quarters\stata\neg_series_not_smoothed\"
local flist : dir . files "*.dta"
dis `"`flist'"'
foreach f in `flist' {
    append using "`f'"

}

gen qtr=yq(year, quarter)
format qtr %tq
label variable Disapproval_Not_Smoothed "Executive Disapproval: Not Smoothed"
duplicates drop
sort state year quarter

saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly neg not smoothed.dta", replace version(12)

** merge files

clear
use "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly app_appdis smoothed.dta", clear
sort state year quarter
merge 1:1 state qtr using "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly app_appdis not smoothed.dta"
drop _merge

sort state year quarter
merge 1:1 state qtr using "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly app smoothed.dta"
drop _merge

sort state year quarter
merge 1:1 state qtr using "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly app not smoothed.dta"
drop _merge

sort state year quarter
merge 1:1 state qtr using "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly neg smoothed.dta"
drop _merge

sort state year quarter
merge 1:1 state qtr using "[directory]\files and code for SEAD dataset v1\Quarters\stata\GOVERNOR quarterly neg not smoothed.dta"
drop _merge

rename app_appdis_Smoothed Relative_Smoothed
rename app_appdis_Not_Smoothed Relative_Not_Smoothed

sort state
encode state, gen (state_code)
xtset state_code qtr

order state state_code year quarter qtr Approval_Smoothed Approval_Not_Smoothed Disapproval_Smoothed Disapproval_Not_Smoothed Relative_Smoothed  Relative_Not_Smoothed
label variable Relative_Smoothed "Relative Executive Approval: Smoothed"
label variable Relative_Not_Smoothed "Relative Executive Approval: Not Smoothed"
compress

** get rid of the ones where the data are bad
replace  Approval_Smoothed =. if Approval_Smoothed<=3
replace  Approval_Not_Smoothed =. if Approval_Not_Smoothed<=3
replace  Relative_Smoothed=. if Relative_Smoothed<=3
replace  Relative_Not_Smoothed=. if Relative_Not_Smoothed<=3
replace  Disapproval_Smoothed =. if Disapproval_Smoothed<=3
replace  Disapproval_Not_Smoothed =. if Disapproval_Not_Smoothed<=3

** merge in the valid counts

sort state quarter_year
merge state quarter year using "[directory]\files and code for SEAD dataset v1\Quarters\stata\log_app_smooth"

label data "Governor Approval May 20, 2021: Quarterly"

saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\SEAD governor quarterly v1.dta", replace version(12)


