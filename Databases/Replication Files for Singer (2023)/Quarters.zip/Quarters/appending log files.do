*APPENDING R log files FOR QUARTERS

** AFTER CLEANING THE LOG FILES AS DECSRIBED IN THE README FILE, the user should replace "[directory]" with their working directory and then run the following analysis to generate the number of valid surveys in the quarter. That is then saved as "log_app_smooth.dta".

clear
use "[directory]\Quarters\state names.dta", clear

levelsof state, local(levels)
clear
cd "[directory]\files and code for SEAD dataset v1\Quarters\logs\"
foreach a of local levels {
import delimited "`a'_q_app_smooth.txt", delimiter(space) clear 
gen state="`a'"
rename v1 count_state
rename v2 quarter_year
rename v3 valid_surveys

sa "[directory]\files and code for SEAD dataset v1\Quarters\valid survey inputs\wcalc_`a'_log_app_smooth.dta", replace
}

cd "[directory]\files and code for SEAD dataset v1\Quarters\valid survey inputs\"
local flist : dir . files "*.dta"
dis `"`flist'"'
foreach f in `flist' {
    append using "`f'"

}
 
duplicates drop
sort state quarter_year
saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\log_app_smooth", replace version(12)

** users wishing to make their own version of the SEAD dataset then need to merge this with the latent variables and generate the valid quarters measure as described in the codebook. That is accomplished by the following steps. 

clear

use "[directory]\files and code for SEAD dataset v1\Quarters\stata\SEAD governor quarterly v1.dta"
sort state quarter_year
merge state quarter_year using "[directory]\files and code for SEAD dataset v1\Quarters\stata\log_app_smooth"

drop _merge

tsset staten qtr
gen valid_3qtr=0
replace valid_3qtr=1 if valid_surveys~=0 | l.valid_surveys~=0 | l2.valid_surveys~=0

label var valid_3qtr "dummy variable for it or one of the 2 previous quarters not being imputed"

saveold "[directory]\files and code for SEAD dataset v1\Quarters\stata\SEAD governor quarterly v1.dta", replace version(12)
